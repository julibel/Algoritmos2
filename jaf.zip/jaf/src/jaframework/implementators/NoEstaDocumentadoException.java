package jaframework.implementators;

/**
 * Created by usuario on 01/08/14.
 */
public class NoEstaDocumentadoException extends RuntimeException {
}
